declare module '*.png' {
  const src: string;
  export default src;
}
declare module '*.jpg';
declare module '*.gif';
declare module '*.svg';
declare module '*.module.css';